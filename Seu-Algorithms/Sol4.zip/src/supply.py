import numpy as np
import itertools

D = np.array([[50,20,30,10],[60,35,20,5],[55,30,25,8],[70,32,28,9]])
S = np.array([[63,25,26,8],[54,31,25,4],[62,29,26,6],[48,18,40,7]])

ms_max = 0
for s in itertools.permutations(S):
    ms = 0
    for i in range(4):
        di = D[i]
        si = s[i]
        d_norm = np.linalg.norm(di)
        s_norm = np.linalg.norm(si)
        ms += np.dot(di,si)/(d_norm*s_norm)
    if ms > ms_max:
        ms_max = ms
        optimal_S = s


print('Demand matrix:')
print('\n'.join(str(row) for row in D))
print('')
print('Optimal Supply matrix:')
print('\n'.join(str(row) for row in optimal_S))

print('Best matching score {:.4f}'.format(ms_max))
