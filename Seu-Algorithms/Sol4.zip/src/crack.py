from pip import main

def login(password, PASSWORD):
    return password == PASSWORD

def crack(soFar, PASSWORD, maxLength):
	""" Password cracking
	Inputs:
	soFar         the current node
	PASSWORD      the secret password
	maxLength	  maximum password length

	Return:
	password      the cracked password
	"""
	if login(soFar, PASSWORD):
		return soFar

	if len(soFar) == maxLength:
		return ""

	for i in ['0','6','8','9']:
		password = crack(soFar + i, PASSWORD, maxLength)
		if (password != ""):
			return password

	return ""

if __name__ == "__main__":
    while True:
        PASSWORD = input('Please enter the password: ')
        result = crack("", PASSWORD, 10)
        print('Cracking ....')
        print('Password cracked: {}\n'.format(result))