#include <iostream>
#include <vector>
#include <sstream>
#include <cmath>
#include <time.h>
#include <fstream>

#define pi 3.1415926
using namespace std ;
const double R = 6371393;
//平面中点的结构体：包含id、经度、纬度；
struct Spot {
    string id ;
    double lat ;
    double lon ;
} ;
//边界的结构体，分别是x、y的最大最小值，即平面中的点的左右上下的最值；
struct boundryLimitation {
    double xLeftLimit ;
    double xRightLimit ;
    double yButtomLimit ;
    double yTopLimit ;
} ;
//输出结果的结构体，包含两个点的id、两个点的距离、安全与否；
struct Res {
    string idOne ;
    string idTwo ;
    double distance ;
    bool safeOrNot ;
} ;
//节点的结构体，该节点中，包含该节点存储的平面中的点，以及指向下一个节点的指针；
struct Node{
    Spot data ;
    Node* next ;
    Node(){ next = nullptr ; }
} ;
//存着头节点的链表
struct NodeList {
    Node* head ;
} ;

//getSpotList方法：通过csv文件初始化链表，链表存储着包含csv文件中所有的点的节点。
vector<Spot> getSpotList(){
    vector<Spot> spotlist ;
    ifstream fin("/Users/sufen/1.csv",ios::in);
    string currentRow;
    getline(fin,currentRow);
    while(getline(fin,currentRow)){
        istringstream readstr(currentRow);
        Spot currentSpot ;
        getline(readstr,currentSpot.id,',');
        string tmpStr;
        getline(readstr,tmpStr,',');
        istringstream streamOne(tmpStr);
        streamOne >> currentSpot.lat;
        getline(readstr ,tmpStr,',');
        istringstream streamTwo(tmpStr);
        streamTwo >> currentSpot.lon ;
        spotlist.push_back(currentSpot);
    }
    return spotlist ;
}
//弧度与角度转化：一个圆的弧度是2pi 而一个圆又是360度（角度制），故pi=180度；
double degreeToRadian (double degree){
    return degree*pi/180.0;
}
//通过平面中两点的经纬度值(坐标)，计算两点间的距离(米)；
double getDistance (double latOne,double lonOne,double latTwo,double lonTwo) {
    double latOneForRadian = degreeToRadian(latOne) ;
    double latTwoForRadian = degreeToRadian(latTwo);
    double tmpOne = latOneForRadian-latTwoForRadian ;
    double tmpTwo = degreeToRadian(lonOne)-degreeToRadian(lonTwo) ;
    double tmpThr = 2*R*asin(sqrt(pow(sin(tmpOne/2),2)+ cos(latOneForRadian)*cos(latTwoForRadian)*pow(sin(tmpTwo/2) ,2)));
    return tmpThr;
}

//getBoundryLimitation方法，输入存储节点的数组，返回该数组中所有节点的上下左右边界的最值，以boundryLimitation结构体的形式返回。
boundryLimitation getBoundryLimitation(vector<Spot> spotlist){
    double xLeftLimit = spotlist[0].lat;
    double xRightLimit = spotlist[0].lat;
    double yButtomLimit = spotlist[0].lon ;
    double yTopLimit = spotlist[0].lon ;
    for(int i =1; i<spotlist.size(); i++){
        if(spotlist[i].lat<xLeftLimit) {
            xLeftLimit = spotlist[i].lat;
        }
        if(spotlist[i].lat>xRightLimit) {
            xRightLimit = spotlist[i].lat;
        }
        if(spotlist[i].lon <yButtomLimit) {
            yButtomLimit = spotlist[i].lon ;
        }
        if(spotlist[i].lon >yTopLimit) {
            yTopLimit = spotlist[i].lon ;
        }
    }
    boundryLimitation res= boundryLimitation {};
    res.xLeftLimit = xLeftLimit ;
    res.xRightLimit = xRightLimit ;
    res.yTopLimit = yTopLimit ;
    res.yButtomLimit = yButtomLimit ;
    return res;
}

//getMinDistance方法，输入为存储着节点的数组，返回该数组中所有节点中两两节点的最小值；
double getMinDistance(vector<Spot> spotlist){
    double minDistance = INT_MAX;
    string idOne ;
    string idTwo ;
    for(int i=0;i<spotlist.size(); i++){
        for(int j=i+1; j<spotlist.size(); j++){
            double distance = getDistance(spotlist[i].lat,spotlist[i].lon,spotlist[j].lat, spotlist[j].lon);
            if(distance<minDistance){
                minDistance = distance;
            }
        }
    }
    return minDistance;
}

//listAddLast方法，输入链表和节点，将节点插入链表末尾；
int listAddLast(NodeList * nodelist , Node *node){
    if(nodelist->head == nullptr) {
        nodelist->head = node ;
    } else {
        Node* cur=nodelist->head ;
        while(cur->next != nullptr) {
            cur = cur->next ;
        }
        cur ->next = node ;
    }
    return 0 ;
}

double hashForDelta(int p , vector<Spot> spotlist , double xLeftLimit , double yButtomLimit , double delta){
    //res数组：该数组的大小为p，用于存放p个链表；
    vector<NodeList*> res(p) ;
    //初始化res数组，把里面的p个链表的头节点都指向nullptr；
    for(int i=0;i<p;i++){
        res[i]= new(NodeList);
        res[i]->head =nullptr;
    }
    //countNumber数组：存放int值，数组容量为p；
    int countNumber[p];
    //初始化countNumber数组，把里面的值全初始化为0；
    for(int i =0;i<p;i++){
        countNumber[i]=0;
    }
    for(int i=0;i<spotlist.size();i++){
        int x = int (ceil((spotlist[i].lat-xLeftLimit+0.0000000001) / delta));
        int y = int (ceil((spotlist[i].lon-yButtomLimit+0.000000001) / delta));
        Node* node =new(Node) ;
        node->data = spotlist[i];
        node->next =nullptr;
        countNumber [(x*y)%p]++;
        listAddLast(res[(x*y)%p], node);
    }
    int idWhenMax = 0 ;
    int maxValue = 0 ;
    for(int i=0;i<p;i++){
        if(maxValue < countNumber[i]) {
            idWhenMax = i ;
            maxValue = countNumber[i];
        }
    }

    int size = spotlist.size();
    double newDelta=0;
    vector<Spot> tmp;
    Node* cur = res[idWhenMax]->head ;
    while(cur !=nullptr) {
        tmp.push_back(cur->data);
        cur = cur->next ;
    }
 
    while(tmp.size()> sqrt(size)){
        vector<Spot> tmpOne ;
        vector<Spot> tmpTwo ;
        vector<Spot> tmpThr ;
        vector<Spot> tmpFour ;
        boundryLimitation boundry = getBoundryLimitation(tmp);
        double midx =(boundry.xRightLimit+boundry.xLeftLimit) /2;
        double midy =(boundry.yTopLimit+boundry.yButtomLimit) /2;
        for(int i=0; i<tmp.size();i++){
            if(tmp[i].lon > midy && tmp[i].lat >midx){
                tmpFour.push_back(tmp[i]);
            }
            if(tmp[i].lat<midx && tmp[i].lon >midy){
                tmpThr.push_back(tmp[i]);
            }
            if(tmp[i].lat<midx && tmp[i].lon <midy){
                tmpOne.push_back(tmp[i]);
            }
            if(tmp[i].lat> midx && tmp[i].lon <midy){
                tmpTwo.push_back(tmp[i]);
            }
        }
        tmp.clear();
        if(tmp.size() < tmpOne.size()){
            tmp = tmpOne ;
        }
        if(tmp.size() < tmpTwo.size()){
            tmp = tmpTwo ;
        }
        if(tmp.size()< tmpThr.size()){
            tmp = tmpThr ;
        }
        if(tmp.size()< tmpFour.size()){
            tmp = tmpFour ;
        }
    }
    newDelta = getMinDistance(tmp);
    //返回方格中最近点距newDelta；
    return newDelta ;
}


Res deltaForMinDistansce(int numRow, int numCol , double delta , vector<Spot> spotlist , double xLeftLimit , double yButtomLimit) {
    vector <vector<NodeList *>> gridRanks(numRow - 1);
    for (int i = 0; i < numRow - 1; i++) {
        gridRanks[i].resize(numCol - 1);
    }
    for (int i = 0; i < numRow - 1; i++) {
        for (int j = 0; j < numCol - 1; j++) {
            gridRanks[i][j] = new(NodeList);
            gridRanks[i][j]->head = nullptr;
        }
    }
    for (int i = 0; i < spotlist.size(); i++) {
        int x = int(ceil((spotlist[i].lat - xLeftLimit + 0.0000000001) / delta) - 1);
        int y = int(ceil((spotlist[i].lon - yButtomLimit + 0.000000001) / delta) - 1);
        if (x > 0 && y > 0) {
            Node *node = new(Node);
            node->data = spotlist[i];
            listAddLast(gridRanks[x - 1][y - 1], node);
        }
        if (x > 0 && y < numCol - 1) {
            Node *node = new(Node);
            node->data = spotlist[i];
            listAddLast(gridRanks[x - 1][y], node);
        }
        if (x < numRow - 1 && y > 0) {
            Node *node = new(Node);
            node->data = spotlist[i];
            listAddLast(gridRanks[x][y - 1], node);
        }
        if (x < numRow - 1 && y < numCol - 1) {
            Node *node = new(Node);
            node->data = spotlist[i];
            listAddLast(gridRanks[x][y], node);
        }
    }
    double minDistance = INT_MAX;
    string idOne;
    string idTwo;
    for (int i = 0; i < numRow - 1; i++) {
        for (int j = 0; j < numCol - 1; j++) {
            Node *cur = gridRanks[i][j]->head;
            vector <Spot> tmpVectorList;
            while (cur != nullptr) {
                tmpVectorList.push_back(cur->data);
                cur = cur->next;
            }
            for (int k = 0; k < tmpVectorList.size(); k++) {
                for (int l = k + 1; l < tmpVectorList.size(); l++) {
                    double distance = getDistance(tmpVectorList[k].lat, tmpVectorList[k].lon, tmpVectorList[l].lat,
                                                  tmpVectorList[l].lon);
                    if (distance < minDistance) {
                        minDistance = distance;
                        idOne = tmpVectorList[k].id;
                        idTwo = tmpVectorList[l].id;
                    }
                }
            }
        }
    }
    Res res = Res{};
    res.idOne = idOne;
    res.idTwo = idTwo;
    res.distance = minDistance;
    if (minDistance < 100) {
        res.safeOrNot = false;
    } else {
        res.safeOrNot = true;
    }
    return res;
}

int main() {
    // 通过getSpotList方法获取平面中点的数组spotlist，该数组中存储着Spot；
    vector<Spot> spotlist = getSpotList() ;
    //getSpotList方法：通过csv文件初始化链表，链表存储着包含csv文件中所有的点的节点。
    int n = spotlist.size();
    int nForSqrt = int(round(sqrt(n)-1)) ;
    vector<Spot> randomSpotList ;
    srand(time(0));
    // 点集spotlist(n个点)中随机取子集randomSpotList，使得|randomSpotList|=√n；
    while(randomSpotList.size()<nForSqrt){
        int i = rand()%n ;
        int numOfRand = randomSpotList.size();
        bool tmpBool = true ;
        for(int j=0; j<numOfRand ; j++){
            if(randomSpotList[j].id == spotlist[i].id){
                tmpBool = false ;
            }
        }
        if(tmpBool){
            randomSpotList.push_back(spotlist[i]);
        }
    }

    const int c = 5 ;
    int p=0;
    for(int i=c*n;i>1;i--){
        bool tmpBool = true ;
        for(int j=2;j<i;j++){
            if(i%j==0){
                tmpBool=false ;
                break ;
            }
        }
        if(tmpBool){
            p = i ;
            break ;
        }
    }

    double newDelta = hashForDelta (p,spotlist,boundry.xLeftLimit,boundry.yButtomLimit,delta)/111000;
    int numRow = int(ceil((boundry.xRightLimit-boundry.xLeftLimit) /newDelta));
    int numCol = int(ceil((boundry.yTopLimit-boundry.yButtomLimit) /newDelta));
    Res res=deltaForMinDistansce(numRow,numCol,newDelta,spotlist,boundry.xLeftLimit,boundry.yButtomLimit) ;
    cout << "(" << res.idOne << ",";
    cout << res.idTwo << ",";
    cout << res.distance << ",";
    if(res.safeOrNot){
        cout << "safe" << “)” << endl;
    } else {
        cout << "danger" << “)” << endl;
    }
}